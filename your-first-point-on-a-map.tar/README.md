# Your First Point on a "Map"

You can view this notebook by running a web server in this directory and
visiting it as a webpage. For example:

```sh
python -m SimpleHTTPServer
# Then, visit http://localhost:8000.
```

Or, use the [Notebook Runtime API](https://github.com/observablehq/notebook-runtime) to
integrate directly with your-first-point-on-a-map.js, which contains the notebook compiled as an
ES module.

*Exported from version 38 of [Your First Point on a "Map"](https://beta.observablehq.com/@milafrerichs/your-first-point-on-a-map) on observablehq.com.*