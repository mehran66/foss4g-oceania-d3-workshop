# Exercise: Load Data

You can view this notebook by running a web server in this directory and
visiting it as a webpage. For example:

```sh
python -m SimpleHTTPServer
# Then, visit http://localhost:8000.
```

Or, use the [Notebook Runtime API](https://github.com/observablehq/notebook-runtime) to
integrate directly with exercise-load-data.js, which contains the notebook compiled as an
ES module.

*Exported from version 96 of [Exercise: Load Data](https://beta.observablehq.com/@milafrerichs/exercise-load-data) on observablehq.com.*